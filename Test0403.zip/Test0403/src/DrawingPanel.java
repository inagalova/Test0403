import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

public class DrawingPanel extends JComponent {
    private int array[] = new int[6];
    private int count = 0;
    private int index = 0;
    private int x;
    private int y;
    Test a;
    private int movePointX = -1;
    private int movePointY = -1;

    public DrawingPanel() {
        super();
        setBackground(Color.GRAY);
        x = -10;
        y = -10;

        addMouseMotionListener(new MouseMotionListener() {

            @Override
            public void mouseDragged(MouseEvent e) {
                // TODO Auto-generated method stub
                if (movePointX != -1 && movePointY != -1) {
                    array[movePointX] = e.getX();
                    array[movePointY] = e.getY();
                    repaint();
                }
            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }

        });

        addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (index < array.length) {
                    array[index] = e.getX();
                    array[index+1] = e.getY();
                    index += 2;
                    repaint();
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                int currentX = e.getX();
                int currentY = e.getY();
                //Point currentPoint(e.getX(), e.getY());
                for (int i = 0; i < index; i += 2) {
                    movePointX = i;
                    movePointY = i + 1;
                    break;
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                movePointX = -1;
                movePointY = -1;
            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    public DrawingPanel(int x, int y) {
        this.x = x;
        this.y = y;
    }
        public void paintComponent (Graphics g)
        {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(getBackground());
            g2d.fillRect(getBounds().x, getBounds().y, getBounds().width,
                    getBounds().height);
            if (index > 0) {
                for (int i = 0; i < index; i += 2) {
                    if (a.cnt == 1) {
                        g2d.setColor(Color.BLACK);
                    }
                    if (a.cnt == 2) {
                        g2d.setColor(Color.WHITE);
                    }
                    if (a.cnt == 3) {
                        g2d.setColor(Color.BLUE);
                    }
                    if (a.cnt == 4) {
                        g2d.setColor(Color.GREEN);
                    }
                    if (a.cnt == 5) {
                        g2d.setColor(Color.RED);
                    }
                    Ellipse2D ellipse = new Ellipse2D.Double(array[i] - 5, array[i + 1] - 5, 10, 10);
                    g2d.draw(ellipse);
                    g2d.fill(ellipse);
                }
            }

            if (index == 6) {
                g2d.setColor(Color.BLACK);
                Line2D line1 = new Line2D.Double(array[0], array[1], array[2], array[3]);
                Line2D line2 = new Line2D.Double(array[2], array[3], array[4], array[5]);
                Line2D line3 = new Line2D.Double(array[4], array[5], array[0], array[1]);
                g2d.draw(line1);
                g2d.draw(line2);
                g2d.draw(line3);


                /*int n = (array[0] + array[2])/2;
                int m = (array[1]+ array[3])/2;
                Line2D m1 = new Line2D.Double(array[0], array[1], 69, 39);
                g2d.draw(m1);*/

            }
        }
    }
