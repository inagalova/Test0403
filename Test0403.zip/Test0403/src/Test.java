import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test {
    public static int cnt = 0;
    public static void main(String[] args) {
        JFrame window = new JFrame("GUI App");
        window.setBounds(200, 200, 500, 750);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        window.setLayout(null);

        JButton black = new JButton();
        black.setBounds(10, 10, 50, 50);
        black.setBackground(Color.BLACK);
        black.setForeground(Color.GRAY);
        window.add(black);
        black.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cnt = 1;
            }
        });

        JButton white = new JButton();
        white.setBounds(60, 10, 50, 50);
        white.setBackground(Color.WHITE);
        white.setForeground(Color.GRAY);
        window.add(white);
        white.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cnt = 2;
            }
        });

        JButton blue = new JButton();
        blue.setBounds(110, 10, 50, 50);
        blue.setBackground(Color.BLUE);
        blue.setForeground(Color.GRAY);
        window.add(blue);
        blue.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cnt = 3;
            }
        });

        JButton green = new JButton();
        green.setBounds(160, 10, 50, 50);
        green.setBackground(Color.GREEN);
        green.setForeground(Color.GRAY);
        window.add(green);
        green.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cnt = 4;
            }
        });

        JButton red = new JButton();
        red.setBounds(210, 10, 50, 50);
        red.setBackground(Color.RED);
        red.setForeground(Color.GRAY);
        window.add(red);
        red.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cnt = 5;
            }
        });

        DrawingPanel p = new DrawingPanel();
        p.setBounds(10, 40, 1000, 1000);
        window.add(p);
    }
}
